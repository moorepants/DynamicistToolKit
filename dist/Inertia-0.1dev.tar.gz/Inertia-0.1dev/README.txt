This is package for basic inertia manipulation.
